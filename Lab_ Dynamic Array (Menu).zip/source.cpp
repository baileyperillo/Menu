
int tax = 0.0866;
int main(){
   
   return 0;
}